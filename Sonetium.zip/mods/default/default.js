const notes = document.getElementById("notes");

document.addEventListener("DOMContentLoaded", () => {

 let particles = "♭♬☆♩♪✩";

 // Function to create an animated particle
 const createParticle = () => {
  const span = document.createElement("span");

  span.textContent = particles[Math.floor(Math.random() * particles.length)];
  span.style.position = "absolute";

  span.style.left = Math.random() * window.innerWidth + "px";

  span.style.top = Math.random() * window.innerHeight + "px";
  span.style.transition = "transform 0.6s ease";
  span.style.pointerEvents = "none"; // Makes sure that the particle does not interfere with mouse events
  notes.appendChild(span);
  

  setInterval(() => {
   span.style.transform = `rotate(${Math.random() * 360}deg)`;
  }, 500);
  // Animação da notas
  let animationDuration = Math.random() * 2 + 2; // Duration between 2-4 seconds
  span.animate([
   { transform: "translateY(0)", opacity: 1 },
   { transform: "translateY(-100px)", opacity: 0 }
        ], {
   duration: animationDuration * 1000,
   easing: "ease-in",
   fill: "forwards"
  });


  //remoção de notas
  setTimeout(() => {
   notes.removeChild(span);
  }, animationDuration * 1000);
 };

 setInterval(createParticle, 300);
 //intervalo de surgimento de notas

});

