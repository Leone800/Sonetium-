function conection(){
if ('connection' in navigator) {
 const connection = navigator.connection || navigator.mozConnection || navigator.webkitConnection;

 console.log(`Tipo de conexão: ${connection.effectiveType}`);
 console.log(`Velocidade estimada da rede: ${connection.downlink} Mbps`);
 console.log(`Modo de economia de dados: ${connection.saveData ? 'Ativo' : 'Inativo'}`);

 // Escutando mudanças na conexão
 connection.addEventListener('change', () => {
  console.log(`Nova conexão: ${connection.effectiveType}`);
 });
} else {
 console.log("API Network Information não suportada neste navegador.");
}
};
conection();

