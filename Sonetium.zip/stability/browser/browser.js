//Essa parte é ajustado a compatibilidade do jogo com a GPU do celular e do Navegador como maneira de não causar bugs no desempenho.
function compatibility() {
 const userAgent = navigator.userAgent;

 // Exemplo de exibição
 console.log("User-Agent:", userAgent);

 // Verificando o sistema operacional e arquitetura
 if (userAgent.includes("Android")) {
  console.log("Sistema: Android");

  if (userAgent.includes("arn")) {
   console.log("Arquitetura: ARM");

  } else if (userAgent.includes("x86")) {
   console.log("Arquitetura: x86");
  }
 }
 if (userAgent.includes("iPhone")) {
  console.log("Sistema: iPhone");
 }

 if (userAgent.includes("pc")) {
  console.log("Ainda não a compatibilidade com PCs por favor aguarde novas atualizações 🙂");
 }
}
compatibility()

