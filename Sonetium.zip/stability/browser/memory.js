function memory(){
 if ('deviceMemory' in navigator) {
    const memory = navigator.deviceMemory;
    console.log(`Memória aproximada: ${memory}GB`);
}
};
memory();

async function detectCpuType() {
    const start = performance.now();
    for (let i = 0; i < 1e7; i++) {} // Operação pesada para medir tempo
    const end = performance.now();
    console.log(`Tempo gasto: ${(end - start).toFixed(2)}ms`);

    if (end - start > 100) {
        console.log("Provavelmente ARM (ARM 64 ou 32)");
    } else {
        console.log("Provavelmente x86(X86)");
    }
}

detectCpuType();

