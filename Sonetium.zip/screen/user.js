const userBar = document.createElement("div");

userBar.style.position = "absolute";
userBar.style.background = "white";
userBar.style.width = "100%";
userBar.style.height = "2rem";

userOne.appendChild(userBar);

