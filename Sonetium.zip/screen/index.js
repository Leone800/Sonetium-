const screenUser = document.getElementById("raiz");
const touch = document.getElementById("touch");

const userOne = document.createElement("div");

userOne.style.height = "100%";
userOne.style.width = "100%";
userOne.style.background = "blue";
userOne.style.display = "none";
userOne.style.position = "absolute";
userOne.style.overflow = "hidden";

screenUser.addEventListener("click", () =>{
 
 touch.style.display = "none";
 userOne.style.display = "flex";
 screenUser.appendChild(userOne);
 
});

const userType = document.createElement("script");

userType.src = "/screen/user.js";

document.body.appendChild(userType)

